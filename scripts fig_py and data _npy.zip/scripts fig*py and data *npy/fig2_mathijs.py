import matplotlib.pyplot as plt
from matplotlib import gridspec
import numpy as np
from mpl_toolkits.axes_grid1.inset_locator import zoomed_inset_axes
from mpl_toolkits.axes_grid1.inset_locator import mark_inset


f = plt.figure(figsize=(4,7))

spec = gridspec.GridSpec(ncols=1, nrows=3, height_ratios=[2, 2, 2])

ax1 = f.add_subplot(spec[0])
ax2 = f.add_subplot(spec[1])
ax3 = f.add_subplot(spec[2])
f.tight_layout(pad=0.3)
f.tight_layout(rect=[0.03,0.0,1.0,1.0])
#f.tight_layout(h_pad=1.0,w_pad=-0.5)

linesum = []
labellist = ['0.001','0.01','0.1','0.5','1','10']
colorlist = ['r','magenta','orange','lime','green','b','k'] # ''r']) # 'yo-' as the style for line+marker, remove cyan
x1,x2,y1,y2 = 0,12,1e-4,1e+0
scalefactor = 0.25
axins = zoomed_inset_axes(ax1, scalefactor,bbox_to_anchor=(0.5,0.4,0.5,0.6),bbox_transform=ax1.transAxes,loc=4)# loc=7) # zoom = 600 times, loc=4 for lower right
k = 0
for ilc in [1,4,7,9,10,13]: 
		if ilc>9:
                        a1x=np.load('18_1_dashed_plot_3d_a1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_a1y'+str(ilc)+'.npy')
			line2,= ax1.plot(a1x,a1y,linewidth=2.5, linestyle="--", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			line2ins,= axins.plot(a1x,a1y,linewidth=2.5, linestyle="--", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
		elif ilc==1:
                        a1x=np.load('18_1_dashed_plot_3d_a1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_a1y'+str(ilc)+'.npy')
			line2,= ax1.plot(a1x,a1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			line2ins,= axins.plot(a1x,a1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
                else:
                        a1x=np.load('18_1_dashed_plot_3d_a1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_a1y'+str(ilc)+'.npy')
			line2,= ax1.plot(a1x,a1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			line2ins,= axins.plot(a1x,a1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
		k+=1
ax1.set_xlabel(r'$x/\sigma$',labelpad=-4) # basically raw string same format as latex, r'$\lambda$' etc..
ax1.set_ylabel(r'$|\rho_{+}+\rho_{-}+\rho_0-2\rho_{b}-\rho_{0,b}|\sigma^3$',labelpad=-1)
axins.set_xlim(x1, x2)
axins.set_ylim(y1, y2)
axins.set_yscale('log')
axins.set_xticks([0,3,6,9,12])
axins.tick_params(pad=-2)
linesum = tuple(linesum)
ax1.tick_params(axis='both',which='major') #,labelsize=15) #('log')
ax1.legend(linesum,[i.get_label() for i in linesum],loc=0,ncol=2,frameon=False,shadow=False,handlelength=1.5,framealpha=1.0, labelspacing=0.0)#fontsize=12,)
ax1.set_xlim([0,7])
ax2.set_xlim([0,7])
ax3.set_xlim([0,7])
ax1.set_ylim([1e-4,1e+2])
ax2.set_ylim([1e-6,1e+2])
ax1.set_xticks([0,2,4,6])
ax2.set_xticks([0,2,4,6])
ax3.set_xticks([0,2,4,6])
ax1.set_yticks([1e-4,1e-2,1e+0,1e+2])
ax2.set_yticks([1e-6,1e-4,1e-2,1e+0])
ax3.set_yticks([-2,-1,0,1,])
ax3.set_ylim([1e-4,1e+2])
ax1.set_yscale('log')
'--------------------------------------------------------------'
'--------------------------------------------------------------'
'--------------------------------------------------------------'

x1,x2,y1,y2 = 0,12,1e-6,1e+0
scalefactor = 0.25
axins = zoomed_inset_axes(ax2, scalefactor,bbox_to_anchor=(0.53,0.72,0.46,0.41),bbox_transform=ax2.transAxes,loc=4)# loc=7) # zoom = 600 times, loc=4 for lower right
k = 0
for ilc in [1,4,7,9,10,13]: 
		if ilc>9:
                        b1x=np.load('18_1_dashed_plot_3d_b1x'+str(ilc)+'.npy')
                        b1y=np.load('18_1_dashed_plot_3d_b1y'+str(ilc)+'.npy')
			line2,= ax2.plot(b1x,b1y,linewidth=2.5, linestyle="--", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			line2ins,= axins.plot(b1x,b1y,linewidth=2.5, linestyle="--", color=colorlist[k],label=r't/$\tau$='+labellist[k])
		elif ilc==1:
                        b1x=np.load('18_1_dashed_plot_3d_b1x'+str(ilc)+'.npy')
                        b1y=np.load('18_1_dashed_plot_3d_b1y'+str(ilc)+'.npy')
			line2,= ax2.plot(b1x,b1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			line2ins,= axins.plot(b1x,b1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
                else:
                        b1x=np.load('18_1_dashed_plot_3d_b1x'+str(ilc)+'.npy')
                        b1y=np.load('18_1_dashed_plot_3d_b1y'+str(ilc)+'.npy')
			line2,= ax2.plot(b1x,b1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			line2ins,= axins.plot(b1x,b1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
		k+=1
ax2.set_xlabel(r'$x/\sigma$',labelpad=-4) # basically raw string same format as latex, r'$\lambda$' etc..
ax2.tick_params(axis='both',which='major') #,labelsize=15) #('log')
ax2.set_ylabel(r'$|\rho_{+}-\rho_{-}|\sigma^3$',labelpad=-1)
ax2.set_yscale('log')
axins.tick_params(pad=-2)
axins.set_yscale('log')
axins.set_xticks([0,3,6,9,12])
axins.set_xlim(x1, x2)
axins.set_ylim(y1, y2)
'--------------------------------------------------------------'
'--------------------------------------------------------------'
'--------------------------------------------------------------'

stylesingle = (['k','b','r','green','orange','lime','cyan','magenta']) # ''r']) # 'yo-' as the style for line+marker, remove cyan
stylesingle.extend(['r','b','green','orange','lime','cyan','k','magenta']) # ''r']) # 'yo-' as the style for line+marker, remove cyan
labellist = ['3.5','2','1','0.5','0.1','0.05']
titlelist = ['fglp00','fglm00','fglk00','fgli00','fglg00','fglf00'] #'fgli00','fglg00','fglf00']
linesum = []
for ilc in range(6):
    a1x = np.load('18_4q_rene_a1x'+str(ilc)+'.npy')
    a1y = np.load('18_4q_rene_a1y'+str(ilc)+'.npy')
    a2x = np.load('18_4q_rene_a2x'+str(ilc)+'.npy')
    a2y = np.load('18_4q_rene_a2y'+str(ilc)+'.npy')
    line1,= ax3.plot(a1x,a1y,linewidth=2.5, linestyle="-", color=stylesingle[ilc],label=r'$\rho_b$='+str(labellist[ilc])+'M ') #+title1) #label=title1+r' $\rho_b$={0:.4f}'.format(rhoionlist[k]))
    line2,= ax3.plot(a2x,a2y,linewidth=2.5, linestyle="--", color=stylesingle[ilc],label=r'$\rho_b$='+str(labellist[ilc])+'M ') #+title1) #label=title1+r' $\rho_b$={0:.4f}'.format(rhoionlist[k]))
    linesum.append(line1)

linesum = tuple(linesum)
#ax1.tick_params(axis='both',which='major',labelsize=15) #('log')
#ax1.text(-0.6,1.15,'(c)',size=18)
ax3.text(2.5,-0.9,r'Solid: ($\rho_+-\rho_{-})\sigma^3$',size=10)
ax3.text(2.5,-0.6,r'Dashed: $\rho_0\sigma^3$',size=10)
ax3.set_ylim(-2,1)
ax3.set_xlabel(r'$x/\sigma$',labelpad=-2.0) # basically raw string same format as latex, r'$\lambda$' etc..
ax3.legend(linesum,[i.get_label() for i in linesum],ncol=2,loc=0,frameon=False,shadow=False,handlelength=1.5,framealpha=1.0, labelspacing=0.0)#fontsize=12,

ax1.yaxis.set_ticks_position('both')
ax1.xaxis.set_ticks_position('both')
ax2.yaxis.set_ticks_position('both')
ax2.xaxis.set_ticks_position('both')
ax3.yaxis.set_ticks_position('both')
ax3.xaxis.set_ticks_position('both')

ax1.tick_params(axis='both',direction='in', which='both')
ax2.tick_params(axis='both',direction='in', which='both')
ax3.tick_params(axis='both',direction='in', which='both')


#ax1.set_xscale("log")
#ax2.set_xscale("log")
#ax3.set_xscale("log")


#ax2.set_xlim(2.5,12000)
#ax3.set_xlim(2.5,12000)
#ax3.set_ylim(0,3.5)


#plt.setp(ax1.get_xticklabels(), visible=False)
#plt.setp(ax2.get_xticklabels(), visible=False)
#plt.setp(ax3.get_xticklabels())
#ax1.tick_params(labeltop=True)


plt.text(0.01, 0.98, '(a)', fontsize=12, transform=plt.gcf().transFigure)
plt.text(0.01, 0.65, '(b)', fontsize=12, transform=plt.gcf().transFigure)
plt.text(0.01, 0.32, '(c)', fontsize=12, transform=plt.gcf().transFigure)


#ax1.legend(shadow=False, loc='lower right',	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0) 
#ax2.legend(shadow=False, loc='lower right', 	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0) 
#ax3.legend(shadow=False, loc='upper center', 	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0)  
#f.savefig("fig5.pdf", bbox_inches = "tight")
plt.subplots_adjust(bottom=0.05, left=0.14)
plt.show() 


