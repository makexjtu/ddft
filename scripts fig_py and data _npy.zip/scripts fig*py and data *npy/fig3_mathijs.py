import matplotlib.pyplot as plt
from matplotlib import gridspec
import numpy as np
from mpl_toolkits.axes_grid1.inset_locator import zoomed_inset_axes
from mpl_toolkits.axes_grid1.inset_locator import mark_inset


#plt.rc('text', usetex=True)
#plt.rc('font', family='serif')
f = plt.figure(figsize=(4,7))

spec = gridspec.GridSpec(ncols=1, nrows=3, height_ratios=[2, 2, 2])

ax1 = f.add_subplot(spec[0])
ax2 = f.add_subplot(spec[1])
ax3 = f.add_subplot(spec[2])
#f.tight_layout(pad=1.0)
#f.tight_layout(h_pad=1.0,w_pad=4.5)
f.tight_layout(rect=[0.03,0.0,1.0,1.0])

timestep = 0.5e-3
stylesingle = (['k','b','r','green','orange','lime','cyan','magenta']) # ''r']) # 'yo-' as the style for line+marker, remove cyan
titlelist = ['fglp00','fglm00','fglk00']
titlelist1= ['fglp00','fglm00','fglk00','fgli00','fglg00','fglf00']
labelmolarlist1= ['3.5','2.0','1.0','0.5','0.1','0.05']
labelappendix = ['','','']
ilc = 0
k = 0
linesum = []
for title1 in titlelist1:
                a1x=np.load('18_4q_b1x'+str(ilc)+'.npy')
                a1y=np.load('18_4q_b1y'+str(ilc)+'.npy')
                line31,= ax1.plot(a1x,a1y,color=stylesingle[k], linewidth=2.5, linestyle="-",label=r'$\rho_b$='+str(labelmolarlist1[k])+'M ') #+title1) #label=title1+r' $\rho_b$={0:.4f}'.format(rhoionlist[k]))
		linesum.append(line31)
	        ilc+=1
	        k+=1
linesum = tuple(linesum)
ax1.set_xlabel(r"$t/\tau$",fontsize=10,labelpad=-3.5) #ormat as latex, r'$\lambda$' etc..
ax1.set_ylabel(r"$Q(t) $",fontsize=10,labelpad=-5)
ax1.set_xlim([0.0,10.0]) #r"Electrode Charges Q (|e|)")
ax1.set_xticks([0,3,6,9]) #r"Electrode Charges Q (|e|)")
ax1.set_ylim([0.0,0.09]) #r"Electrode Charges Q (|e|)")
ax1.set_yticks([0,0.03,0.06]) #r"Electrode Charges Q (|e|)")
#ax.set_yscale('log')
ax1.tick_params(axis='both',which='major',labelsize=12) #('log')
#ax1.text(-1.4,0.085,'(a)',size=18)
ax1.legend(linesum,[i.get_label() for i in linesum],loc=4,frameon=False)


titlelist = ['fglp00','fglm00','fglk00']
ilc = 0
k = 0
linesum = []
for title in titlelist:
                if title[-6:]!='fglp00':
                        a1x = np.load('18_4f_a1x'+str(ilc)+'.npy')
                        a1y = np.load('18_4f_a1y'+str(ilc)+'.npy')
                        a2x = np.load('18_4f_a2x'+str(ilc)+'.npy')
                        a2y = np.load('18_4f_a2y'+str(ilc)+'.npy')
		        line3,= ax2.plot(a1x,a1y,color=stylesingle[k], linewidth=2.5, linestyle="-",label=r'$\rho_b$='+str(labelmolarlist1[k])+'M'+labelappendix[k])
        		line31,= ax2.plot(a2x,a2y,color=stylesingle[k], linewidth=2.5, linestyle="--") #,label=r'$\rho_b$='+str(labelmolar)+'M')
                else:
                        a1x = np.load('18_4f_a1x'+str(ilc)+'.npy')
                        a1y = np.load('18_4f_a1y'+str(ilc)+'.npy')
                        a2x = np.load('18_4f_a2x'+str(ilc)+'.npy')
                        a2y = np.load('18_4f_a2y'+str(ilc)+'.npy')
		        line3,= ax2.plot(a1x,a1y,color=stylesingle[k], linewidth=2.5, linestyle="-",label=r'$\rho_b$='+str(labelmolarlist1[k])+'M'+labelappendix[k])
        		line31,= ax2.plot(a2x,a2y,color=stylesingle[k], linewidth=2.5, linestyle="--") #,label=r'$\rho_b$='+str(labelmolar)+'M')
		linesum.append(line3)
                ilc+= 1
                k+= 1
#linesum.append(line31st)
linesum = tuple(linesum)
ax2.set_xlabel(r'$t/\tau$',fontsize=10,labelpad=-3) # basically raw string same format as latex, r'$\lambda$' etc..
ax2.set_xlim([0,15])
ax2.set_xticks([0,5,10,15])
#ax.set_ylabel(r"$1-Q(t)/Q_{eq}$")
ax2.set_ylim([1e-8,5e+1])
#ax2.set_ylabel(r"$(c(t)-c_{eq})/(c_0-c_{eq})$")
ax2.set_yscale('log')
ax2.set_yticks([1e-6,1e-4,1e-2,1.0])
#ax2.set_yscale('log')
ax2.legend(linesum,[i.get_label() for i in linesum],loc=4,frameon=False)
ax2.text(5.0,1e-1,r'Solid: Charge $|1-Q(t)/Q_{eq}|$',size=10)
ax2.text(5.0,10,r'Dashed: Total Concentration',size=10)
ax2.text(5.0,1,r'$(c_t(t)-c_{t,eq})/(c_t(0)-c_{t,eq})$',size=10)
#ax2.text(-1.5,10,'(b)',size=18)
ax2.tick_params(axis='both',which='major',labelsize=12) #('log')
#plt.subplots_adjust(bottom=0.12)

titlelist = ['fglp00','fglm00','fglk00'] #'newer_egl/fgli00','newer_egl/fglg00','newer_egl/fglf00']
ilc = 0
k = 0
linesum = []
for title in titlelist:
                a1x=np.load('17_4g_rene_a1x'+str(ilc)+'.npy')
                a1y=np.load('17_4g_rene_a1y'+str(ilc)+'.npy')
		line0,= ax3.plot(a1x,a1y,color=stylesingle[k], linewidth=2.5, linestyle="-",label=r'$\rho_b$='+str(labelmolarlist1[k])+'M ') #+title)
		linesum.append(line0)
	        ilc+=1
	        k+=1
linesum = tuple(linesum)
ax3.set_xlabel(r"$t/\tau$",fontsize=10,labelpad=-2.5) # basically raw string same format as latex, r'$\lambda$' etc..
ax3.set_ylabel(r"$\tau(t) \times D/(\lambda_D L)$",fontsize=10,labelpad=-1)
ax3.set_xlim([1e-3,1e+2])
ax3.set_ylim([1e-2,1e+1])
ax3.set_xticks([1e-2,1e-1,1,10]) #r"Electrode Charges Q (|e|)")
ax3.set_yticks([1e-1,1,10]) #r"Electrode Charges Q (|e|)")
ax3.set_yscale('log')
ax3.set_xscale('log')
ax3.legend(linesum,[i.get_label() for i in linesum],loc=4,frameon=False)
#ax3.text(1.5e-4,10,'(c)',size=18)
ax3.tick_params(axis='both',which='major',labelsize=12) #('log')
#plt.subplots_adjust(bottom=0.13, left=0.15)

ax1.yaxis.set_ticks_position('both')
ax1.xaxis.set_ticks_position('both')
ax2.yaxis.set_ticks_position('both')
ax2.xaxis.set_ticks_position('both')
ax3.yaxis.set_ticks_position('both')
ax3.xaxis.set_ticks_position('both')

ax1.tick_params(axis='both',direction='in', which='both')
ax2.tick_params(axis='both',direction='in', which='both')
ax3.tick_params(axis='both',direction='in', which='both')


plt.text(0.01, 0.97, '(a)', fontsize=12, transform=plt.gcf().transFigure)
plt.text(0.01, 0.65, '(b)', fontsize=12, transform=plt.gcf().transFigure)
plt.text(0.01, 0.32, '(c)', fontsize=12, transform=plt.gcf().transFigure)


#ax1.legend(shadow=False, loc='lower right',	handlelength=1.5, fontsize=10, 	framealpha=1.0, labelspacing=0.0) 
#ax2.legend(shadow=False, loc='lower right', 	handlelength=1.5, fontsize=10, 	framealpha=1.0, labelspacing=0.0) 
#ax3.legend(shadow=False, loc='upper center', 	handlelength=1.5, fontsize=10, 	framealpha=1.0, labelspacing=0.0)  
#f.savefig("fig5.pdf", bbox_inches = "tight")
#plt.subplots_adjust(bottom=0.05, left=0.14)
plt.show() 


