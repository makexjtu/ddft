import matplotlib.pyplot as plt
from matplotlib import gridspec
import numpy as np
from mpl_toolkits.axes_grid1.inset_locator import zoomed_inset_axes
from mpl_toolkits.axes_grid1.inset_locator import mark_inset


f = plt.figure(figsize=(4,4.5))

spec = gridspec.GridSpec(ncols=1, nrows=2, height_ratios=[2, 2])

ax1 = f.add_subplot(spec[0])
ax2 = f.add_subplot(spec[1])
f.tight_layout(rect=[0.03,0.01,1.0,1.0])
#f.tight_layout(pad=0.3)
#f.tight_layout(h_pad=1.0,w_pad=-0.5)

stylesingle = (['r','k','green','k','green','green','cyan','magenta','r','b','k']) # ''r']) # 'yo-' as the style for line+marker, remove cyan
listlabel = ['','without Dispersion and Solvent']
linesum = []
for klist in range(1):
    a1x = np.load('17_4ah_a1x'+str(0)+'.npy')
    a1y = np.load('17_4ah_a1y'+str(0)+'.npy')
    line1, = ax1.plot(a1x,a1y,color=stylesingle[klist],marker='o',fillstyle='full',linewidth=2.5,ms=10,label=r'$\tau_1$ from DDFT'+listlabel[klist]) #' Ideal+Coulomb+LJ+MSA+SquareWall System ')
    linesum.append(line1)
for klist in range(1,2):
    a1x = np.load('17_4ah_a2x'+str(0)+'.npy')
    a1y = np.load('17_4ah_a2y'+str(0)+'.npy')
    line1, = ax1.plot(a1x,a1y,color=stylesingle[klist],marker='o',fillstyle='none',markeredgewidth=3,linewidth=2.5,ms=10,label=r'$\tau_1$ from DDFT '+listlabel[klist]) #' Ideal+Coulomb+LJ+MSA+SquareWall System ')
    linesum.append(line1)
#line0, = ax.plot(xlist[:],tclistl1[0],linestyle='-',linewidth=2.5,color='b',marker='^',markeredgewidth=2.0,fillstyle='none',ms=10,label=r'$\tau_1=\frac{\kappa^{-1}L}{D(1+\kappa \sigma)}$')
a1x = np.load('17_4ah_a3x'+str(0)+'.npy')
a1y = np.load('17_4ah_a3y'+str(0)+'.npy')
line0, = ax1.plot(a1x,a1y,linestyle='-',linewidth=2.5,color='b',marker='^',markeredgewidth=2.0,fillstyle='none',ms=10,label=r'$\tau_1=\lambda_D L/[D(2+\sigma/\lambda_D)]$')
#line0, = ax.plot(debyelist,tclistfion,color='b',linewidth=2.5,marker='o',ms=10,label=' Purely Free Ion System f1=1.0 ')
linesum.append(line0)
linesum = tuple(linesum)
ax1.set_xlabel(r' $1/(2+\sigma/\lambda_{D})$',fontsize=12,labelpad=-2) # basically raw string same format as latex, r'$\lambda$' etc..
ax1.set_ylabel(r"$\tau_{1} \times D/(\lambda_D L)$",fontsize=12)
ax1.set_xlim([0.0,0.3])
ax1.set_xticks([0,0.1,0.2,0.3])
ax1.set_yticks([0,0.1,0.2,0.3])
ax1.set_ylim([0.0,0.4])
ax1.text(a1x[0]-0.03,a1y[0]-0.06,r'$\rho_b$=0.05M',size=11,color='green')
ax1.text(a1x[1]-0.03,a1y[1]+0.03,r'0.1M',size=11,color='green')
ax1.text(a1x[2]-0.02,a1y[2]+0.05,r'0.5M',size=11,color='green')
ax1.text(a1x[3]+0.005,a1y[3]-0.05,r'1M',size=11,color='green')
ax1.text(a1x[4]-0.01,a1y[4]-0.05,r'2M',size=11,color='green')
ax1.text(a1x[5]-0.01,a1y[5]-0.05,r'$\rho_b$=3.5M',size=11,color='green')
ax1.tick_params(axis='both',which='major',labelsize=12) #('log')
#ax.set_yscale('log')
ax1.legend(linesum,[i.get_label() for i in linesum],loc=2,fontsize=8,frameon=False)

linesum = []
a1x = np.load('17_4h_a1x'+str(0)+'.npy')
a1y = np.load('17_4h_a1y'+str(0)+'.npy')
line3, = ax2.plot(a1x,a1y,color='r',linewidth=2.5,marker='o',ms=10,label=r'$\tau_2$ from DDFT ') #' Ideal+Coulomb+LJ+MSA+SquareWall System ')
a1x = np.load('17_4h_a2x'+str(0)+'.npy')
a1y = np.load('17_4h_a2y'+str(0)+'.npy')
line32, = ax2.plot(a1x,a1y,color='k',linewidth=2.5,marker='o',ms=10,label=r'$\tau_2$ from DDFT without Dispersion and Solvent') #' Ideal+Coulomb+LJ+MSA+SquareWall System ')
a1x = np.load('17_4h_a3x'+str(0)+'.npy')
a1y = np.load('17_4h_a3y'+str(0)+'.npy')
line4, = ax2.plot(a1x,a1y,color='b',marker='^',ms=10,markeredgewidth=2.0,linewidth=2.5,fillstyle='none',label=r'$\tau_2 = L^2/D \times \sqrt{(\lambda_D/{l_c})^{3}}$ ') #' Ideal+Coulomb+LJ+MSA+SquareWall System ')
linesum.append(line3)
linesum.append(line32)
linesum.append(line4)
linesum = tuple(linesum)
ax2.set_xlim([0.2,0.7])
ax2.set_ylim([0,8])
ax2.set_xlabel(r' $\sqrt{\lambda_D/\sigma}$',fontsize=12,labelpad=-2) # basically raw string same format as latex, r'$\lambda$' etc..
ax2.set_ylabel(r' $\tau_2 \times D/(\lambda_D L)$',fontsize=12)
ax2.legend(linesum,[i.get_label() for i in linesum],loc=2,fontsize=8,frameon=False)
ax2.tick_params(axis='both',which='major',labelsize=12) #('log')


ax1.yaxis.set_ticks_position('both')
ax1.xaxis.set_ticks_position('both')
ax2.yaxis.set_ticks_position('both')
ax2.xaxis.set_ticks_position('both')

ax1.tick_params(axis='both',direction='in', which='both')
ax2.tick_params(axis='both',direction='in', which='both')


plt.text(0.01, 0.95, '(a)', fontsize=12, transform=plt.gcf().transFigure)
plt.text(0.01, 0.48, '(b)', fontsize=12, transform=plt.gcf().transFigure)


#ax1.legend(shadow=False, loc='lower right',	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0) 
#ax2.legend(shadow=False, loc='lower right', 	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0) 
#ax3.legend(shadow=False, loc='upper center', 	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0)  
#f.loadfig("fig5.pdf", bbox_inches = "tight")
#plt.subplots_adjust(bottom=0.05, left=0.14)
plt.show() 


