import matplotlib.pyplot as plt
from matplotlib import gridspec
import numpy as np
from mpl_toolkits.axes_grid1.inset_locator import zoomed_inset_axes
from mpl_toolkits.axes_grid1.inset_locator import mark_inset


f = plt.figure(figsize=(4,7))
labellist = ['0.001','0.01','0.1','0.5','1','10']
colorlist = ['r','magenta','orange','lime','green','b','k'] # ''r']) # 'yo-' as the style for line+marker, remove cyan

spec = gridspec.GridSpec(ncols=1, nrows=3, height_ratios=[2, 2, 2])

ax1 = f.add_subplot(spec[0])
ax2 = f.add_subplot(spec[1])
ax3 = f.add_subplot(spec[2])
f.tight_layout(pad=0.3)
f.tight_layout(rect=[0.03,0.0,1.0,1.0])
#f.tight_layout(h_pad=1.0,w_pad=-0.5)

timestep = 0.5e-3
stylesingle = (['k','b','r','green','orange','lime','cyan','magenta']) # ''r']) # 'yo-' as the style for line+marker, remove cyan
linesum = []
k = 0
for ilc in [1,4,7,9,10,13]: 
		if ilc>9:
                        a1x=np.load('18_1_dashed_plot_3d_c1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_c1y'+str(ilc)+'.npy')
			line2,= ax1.plot(a1x,a1y,linewidth=2.5, linestyle="--", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
		elif ilc==1:
                        a1x=np.load('18_1_dashed_plot_3d_c1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_c1y'+str(ilc)+'.npy')
			line2,= ax1.plot(a1x,a1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
                else:
                        a1x=np.load('18_1_dashed_plot_3d_c1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_c1y'+str(ilc)+'.npy')
			line2,= ax1.plot(a1x,a1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
		k+=1
ax1.set_xlabel(r'$x/\sigma$',fontsize=12,labelpad=-2) # basically raw string same format as latex, r'$\lambda$' etc..
ax1.set_ylabel(r'$(\rho_{+}+\rho_{-}+\rho_0)\sigma^3$',fontsize=12)
#ax1.set_ylabel(r'$|\rho_0$')
#ax.set_zlabel("Number density "+r'(#/$\sigma^3$)')
#ax.set_xlim([1e-3,1e+3])
ax1.set_ylim([1e-6,2.0])
ax1.set_yticks([0.5,1.0,1.5,2.0])
#ax.set_yscale('log')
ax1.set_xlim([0,5.0])
linesum = tuple(linesum)
ax1.tick_params(axis='both',which='major',labelsize=12) #('log')
ax1.legend(linesum,[i.get_label() for i in linesum],loc=1,frameon=False)

linesum= []
k = 0
for ilc in [1,4,7,9,10,13]: 
		if ilc>9:
                        a1x=np.load('18_1_dashed_plot_3d_d1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_d1y'+str(ilc)+'.npy')
			line2,= ax3.plot(a1x,a1y,linewidth=2.5, linestyle="--", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
		elif ilc==1:
                        a1x=np.load('18_1_dashed_plot_3d_d1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_d1y'+str(ilc)+'.npy')
			line2,= ax3.plot(a1x,a1y,linewidth=4.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
                else:
                        a1x=np.load('18_1_dashed_plot_3d_d1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_d1y'+str(ilc)+'.npy')
			line2,= ax3.plot(a1x,a1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
			#plt.text(coordgr/3.0,ytick[-3],title[-9:-6]+(r' H = {0:.2f}($\sigma$)').format(coordgr),size=20)
#nnn			plt.text(coordgr/3.0,0.8,r'(a) $fs=0.1;f1=0.9 $',size=15)
#			plt.text(coordgr/3.0,0.8,r'(b) $\rho_b \sigma^3 = 0.25$',size=15)
		k+=1
ax3.set_xlabel(r'$x/\sigma$',fontsize=12,labelpad=-2) # basically raw string same format as latex, r'$\lambda$' etc..
#plt.axvline(x=coordgr,linestyle='dashed',color='k') #,color='k')
ax3.set_yticks([-1.5,-1.0,-0.5,0.0,0.5])
#ax.set_ylabel("Simulation Time of Charging"+r'($\tau$)') # basically raw string same format as latex, r'$\lambda$' etc..
ax3.set_ylabel(r'$(\rho_{+}-\rho_{-})\sigma^3$',fontsize=12,labelpad=-6)
#ax.set_zlabel("Number density "+r'(#/$\sigma^3$)')
#ax.set_xlim([1e-3,1e+3])
ax3.set_ylim([-1.5,0.5])
#ax.set_yscale('log')
ax3.set_xlim([0,5])
linesum = tuple(linesum)
#ax.legend(linesum,[i.get_label() for i in linesum],loc=0,frameon=False)
ax3.tick_params(axis='both',which='major',labelsize=12) #('log')

linesum= []
k = 0
for ilc in [1,4,7,9,10,13]: 
		if ilc>9:
                        a1x=np.load('18_1_dashed_plot_3d_e1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_e1y'+str(ilc)+'.npy')
			line2,= ax2.plot(a1x,a1y,linewidth=2.5, linestyle="--", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
		elif ilc==1:
                        a1x=np.load('18_1_dashed_plot_3d_e1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_e1y'+str(ilc)+'.npy')
			line2,= ax2.plot(a1x,a1y,linewidth=4.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
                else:
                        a1x=np.load('18_1_dashed_plot_3d_e1x'+str(ilc)+'.npy')
                        a1y=np.load('18_1_dashed_plot_3d_e1y'+str(ilc)+'.npy')
			line2,= ax2.plot(a1x,a1y,linewidth=2.5, linestyle="-", color=colorlist[k],label=r't/$\tau$='+labellist[k])
			linesum.append(line2)
		k+=1
ax2.set_xlabel(r'$x/\sigma$',fontsize=12,labelpad=-2) # basically raw string same format as latex, r'$\lambda$' etc..
ax2.set_ylabel(r'$\rho_0\sigma^3$',fontsize=12)
ax2.set_ylim([0.15,0.4])
ax2.set_yticks([0.2,0.3,0.4])
ax2.set_xlim([0,5.0])
linesum = tuple(linesum)

ax1.yaxis.set_ticks_position('both')
ax1.xaxis.set_ticks_position('both')
ax2.yaxis.set_ticks_position('both')
ax2.xaxis.set_ticks_position('both')
ax3.yaxis.set_ticks_position('both')
ax3.xaxis.set_ticks_position('both')

ax1.tick_params(axis='both',direction='in', which='both')
ax2.tick_params(axis='both',direction='in', which='both')
ax3.tick_params(axis='both',direction='in', which='both')


plt.text(0.01, 0.97, '(a)', fontsize=12, transform=plt.gcf().transFigure)
plt.text(0.01, 0.65, '(b)', fontsize=12, transform=plt.gcf().transFigure)
plt.text(0.01, 0.32, '(c)', fontsize=12, transform=plt.gcf().transFigure)


#ax1.legend(shadow=False, loc='lower right',	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0) 
#ax2.legend(shadow=False, loc='lower right', 	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0) 
#ax3.legend(shadow=False, loc='upper center', 	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0)  
#f.savefig("fig5.pdf", bbox_inches = "tight")
#plt.subplots_adjust(bottom=0.05, left=0.14)
plt.show() 


