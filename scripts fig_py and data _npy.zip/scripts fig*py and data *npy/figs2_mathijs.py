import matplotlib.pyplot as plt
from matplotlib import gridspec
import numpy as np
from mpl_toolkits.axes_grid1.inset_locator import zoomed_inset_axes
from mpl_toolkits.axes_grid1.inset_locator import mark_inset


f = plt.figure(figsize=(4,4.5))

spec = gridspec.GridSpec(ncols=1, nrows=2, height_ratios=[2, 2])

ax1 = f.add_subplot(spec[0])
ax2 = f.add_subplot(spec[1])
f.tight_layout(pad=0.3)
f.tight_layout(rect=[0.05,0.0,0.910,1.0])

timestep = 0.5e-3
stylesingle = (['k','b','r','green','orange','lime','cyan','magenta']) # ''r']) # 'yo-' as the style for line+marker, remove cyan
stylesingle1= (['b','r','green','orange','lime','cyan','magenta']) # ''r']) # 'yo-' as the style for line+marker, remove cyan
titlelist = ['fglp00','fglm00','fglk00']
labelmolarlist = ['3.5','2.0','1.0']
ilc = 0
k = 0
linesum = []
ax1b = ax1.twinx()
for title in titlelist:
                a1x=np.load('18_4q_a1x'+str(ilc)+'.npy')
                a1y=np.load('18_4q_a1y'+str(ilc)+'.npy')
#                a1y=a1y*float(labelmolarlist[k])
		line0,= ax1.plot(a1x,a1y,color=stylesingle[k], linewidth=2.5, linestyle="-",label=r'$\rho_b$='+str(labelmolarlist[k])+'M ') #+title)
		linesum.append(line0)
                if title[-6:] != 'fglp00':
                    a1x=np.load('18_4q_a2x'+str(ilc)+'.npy')
                    a1y=np.load('18_4q_a2y'+str(ilc)+'.npy')
#                    a1y=a1y*(3.5-float(labelmolarlist[k]))
                    line01,= ax1b.plot(a1x,a1y,color=stylesingle[k], linewidth=2.5, linestyle="--") #,label=r'$\rho_b$='+str(labelmolarlist[k])+'M Solvent $c_0(t)$') #+title)
#		    linesum.append(line01)
		#line31,= ax.plot(time[:t2],logct[:t2],color=stylesingle[k], linewidth=2.5, linestyle="--") #,label=r'$\rho_b$='+str(labelmolar)+'M')
	#	taurc = debyelist[k]*lz*1e-20/diffu/(sigma**2*1e-20/diffu)
	        k+= 1
	        ilc+=1
ax1.set_xscale('log')
ax1.set_ylabel(r'$c(t)/(2\rho_b)$',fontsize=12,labelpad=0) # basically raw string same format as latex, r'$\lambda$' etc..
ax1b.set_ylabel(r'$\rho_0(t)/\rho_{0,b}$',fontsize=12,labelpad=0) # basically raw string same format as latex, r'$\lambda$' etc..
ax1.set_yticks([0.9,0.95,1.0,1.05])
ax1b.set_yticks([1.0,1.01,1.02,1.03])
ax1.legend(linesum,[i.get_label() for i in linesum],loc=3,frameon=False)

ilc = 0
k = 0
linesum = []
titlelist1 = ['fglm00','fglk00']
labelmolarlist1 = ['2.0','1.0']
for title in titlelist1:
                a1x=np.load('18_4f_b1x'+str(ilc)+'.npy')
                a1y=np.load('18_4f_b1y'+str(ilc)+'.npy')
		line31,= ax2.plot(a1x,a1y,color=stylesingle1[k], linewidth=2.5, linestyle="-",label=r'$\rho_b$='+str(labelmolarlist1[k])+'M')
                linesum.append(line31)
                a1x=np.load('18_4f_b2x'+str(ilc)+'.npy')
                a1y=np.load('18_4f_b2y'+str(ilc)+'.npy')
                line32,= ax2.plot(a1x,a1y,color=stylesingle1[k], linewidth=2.5, linestyle="--")
	        k+= 1
        	ilc+= 1
linesum = tuple(linesum)
ax1.set_xlabel(r'$t/\tau$',fontsize=12,labelpad=-2) # basically raw string same format as latex, r'$\lambda$' etc..
ax2.set_xlabel(r'$t/\tau$',fontsize=12,labelpad=-2) # basically raw string same format as latex, r'$\lambda$' etc..
#ax.set_ylim([1e-5,3])
#ax2.set_ylim([1e-5,3.0])
ax2.set_xlim([0,10.5])
#ax2.set_ylabel(r"$1-Q(t)/Q_{eq}$")
ax2.set_ylim([1e-1,4e+0])
#ax22.set_ylabel(r"$(c(t)-c_{eq})/(c_0-c_{eq})$")
ax2.set_yscale('log')
ax2.set_xticks([0.0,5.0,10.0])
ax2.legend(linesum,[i.get_label() for i in linesum],loc=3,frameon=False)
#plt.text(2.5,4e-7,r'Solid: Charge $1-\frac{Q(t)}{Q_{eq}}$',size=16)
ax2.text(1.6,2.9,r'Solid: $(c(t)-c_{eq})/(c(0)-c_{eq})$',size=9)
ax2.text(1.6,2.1,r'Dashed: $(\rho_0(t)-\rho_{0,eq})/(\rho_0(0)-\rho_{0,eq})$',size=9)
#plt.text(2.522e-3,r'Dotted: Solvent Concentration $\frac{c(t)-c_{eq}}{c_0-c_{eq}}$',size=16)
ax2.tick_params(axis='both',which='major',labelsize=12) #('log')

ax1.yaxis.set_ticks_position('both')
ax1.xaxis.set_ticks_position('both')
ax2.yaxis.set_ticks_position('both')
ax2.xaxis.set_ticks_position('both')

ax1.tick_params(axis='both',direction='in', which='both')
ax2.tick_params(axis='both',direction='in', which='both')


plt.text(0.01, 0.95, '(a)', fontsize=12, transform=plt.gcf().transFigure)
plt.text(0.01, 0.48, '(b)', fontsize=12, transform=plt.gcf().transFigure)


#ax1.legend(shadow=False, loc='lower right',	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0) 
#ax2.legend(shadow=False, loc='lower right', 	handlelength=1.5, fontsize=12, 	framealpha=1.0, labelspacing=0.0) 
#f.loadfig("fig5.pdf", bbox_inches = "tight")
plt.show() 


